Assignment 2 - Colby England

****************************************************************
Compilation Intructions
****************************************************************

The file was compiled using the command: 
gcc -o smallsh -Wall -Werror -g3 -std=c11 -O0 smallsh.c

The included file compile.sh will compile the program with the above command
Be sure to run 

% chmod +x ./compile.sh

before running the compile script